declare namespace _exports {
    export { Func };
}
declare const _exports: <T extends Func = Func>(fn: T, length: number, loose?: boolean) => T;
export = _exports;
type Func = (...args: unknown[]) => unknown;
//# sourceMappingURL=index.d.ts.map