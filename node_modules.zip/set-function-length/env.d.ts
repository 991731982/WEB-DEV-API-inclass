export var boundFnsHaveConfigurableLengths: boolean;
export var boundFnsHaveWritableLengths: boolean;
export var functionsHaveConfigurableLengths: boolean;
export var functionsHaveWritableLengths: boolean;
export declare let __proto__: null;
//# sourceMappingURL=env.d.ts.map